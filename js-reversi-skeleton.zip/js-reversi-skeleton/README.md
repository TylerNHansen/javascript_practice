# REVERSI JS STYLE

To run the mocha tests, use the following command in the terminal (in the top level directory of this file:)

`./node_modules/mocha/bin/mocha`